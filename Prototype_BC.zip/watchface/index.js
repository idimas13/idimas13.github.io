try {
  ((() => {
// Системные переменные приложения
      const __$$app$$__ = __$$hmAppManager$$__.currentApp;
      function getApp() {
          return __$$app$$__.app;
      }
      function getCurrentPage() {
          return __$$app$$__.current && __$$app$$__.current.module;
      }
      const __$$module$$__ = __$$app$$__.current;
      const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
      const {px} = __$$app$$__.__globals__;
      const logger = Logger.getLogger('watchface');
  //end of ignored block

// Объявление переменных для виджетов
      // Шрифт
      const proto = 'fonts/Prototype.ttf';
      // Секунды
      let secondWidget;
      function updateSeconds() {
          const sec = timeSens.second;
          // Центр круга
          const centerX = 240;
          const centerY = 240;
          // Радиус движения текста
          const radius = 226;
          // Размер текста (ширина и высота)
          const textWidth = 26;
          const textHeight = 20;
          // Угол в радианах (начиная с -90°, чтобы 0 секунд были вверху)
          const angle = (Math.PI * 2 * sec / 60) - Math.PI / 2;
          // Новые координаты
          const x = centerX + Math.cos(angle) * radius - textWidth / 2;
          const y = centerY + Math.sin(angle) * radius - textHeight / 2;
          // Обновить виджет
          secondWidget.setProperty(hmUI.prop.MORE, {
              x: Math.round(x),
              y: Math.round(y),
              text: sec.toString().padStart(2, "0")
          });
      }
      // Время
      let ampmN = '';
      let timeH = '';
      // Заряд
      let batlevel = '';
      const batsens = hmSensor.createSensor(hmSensor.id.BATTERY);
      // Шаги
      let step_n = '';
      const stepSens = hmSensor.createSensor(hmSensor.id.STEP);
      // Пульс
      let hr_n = '';
      const hrSens = hmSensor.createSensor(hmSensor.id.HEART);
      // PAI
      let pai_n = '';
      const paiSens = hmSensor.createSensor(hmSensor.id.PAI);
      // Дата
      let dateFormat = '';
      let dateFormatMap = '';
      let date_n = '';
      let day_n = '';
      const timeSens = hmSensor.createSensor(hmSensor.id.TIME);
      // Погода и локация
      let temper_n = '';
      let loc_n = '';
      let Tunit = '';
      const wSens = hmSensor.createSensor(hmSensor.id.WEATHER);
      // Готовность
      let readygr = '';
      let rtext = '';
      let ready = '';
      // Калории
      let calgr = '';
      let calD = '';
      let calT = '';
      // Кислород
      let oxygr = '';
      let oxyD = '';
      let oxyU = '';
      let oxyT = '';
      // Стресс
      let stressgr = '';
      let strD = '';
      let strT = '';
// Vibration       
      const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
      const vibro = () => {
          vibrate.stop();
          vibrate.scene = 25;
          vibrate.start();
          setTimeout(() => vibrate.stop(), 50);
      };
// Функция для определения цвета по уровню заряда
      function getbatcolor(level) {
          if (level <= 25) return 0xFF0000;     // Красный
          if (level <= 50) return 0xEB6100;     // Оранжевый
          return 0x00FFFF;                      // Голубой
      }
// Функция для определения цвета шагов
      function getstepcolor(stp) {
          const steptarget = stepSens.target
          if (stp >= steptarget) return 0xFF0000;     // Красный
          if (stp >= steptarget*0.8) return 0xEB6100;     // Оранжевый
          return 0x00FFFF;                      // Голубой
      }
// Цвет PAI
      function getPAIcolor(pai) {
          if (pai >= 200) return 0x7700ff; // фиолетовый
          if (pai >= 100) return 0x00ff00; // зеленый
          if (pai >= 50) return 0x008beb;  // синий
          if (pai >= 10) return 0xffdd00;  // желтый
          return 0x00FFFF;
      }
// Цвет даты
      function getDayColor(val) {
          if (val >= 6) return 0xFF0000;     // Красный
          if (val >= 5) return 0xEB6100;     // Оранжевый
          return 0x00FFFF;                   // Голубой
      }
// Переключатель
      let znum = 0;
      let zqty = 3;
      function touchzone() {
        znum = (znum + 1) % (zqty + 1);
            if (znum == 0) {
                readygr.setProperty(hmUI.prop.VISIBLE, true);
                calgr.setProperty(hmUI.prop.VISIBLE, false);
                oxygr.setProperty(hmUI.prop.VISIBLE, false);
                stressgr.setProperty(hmUI.prop.VISIBLE, false);
                zonelink = () => {
                  hmApp.startApp({ url: 'readinessAppScreen', native: true });
                }
            };
            if (znum == 1) {
                readygr.setProperty(hmUI.prop.VISIBLE, false);
                calgr.setProperty(hmUI.prop.VISIBLE, true);
                oxygr.setProperty(hmUI.prop.VISIBLE, false);
                stressgr.setProperty(hmUI.prop.VISIBLE, false);
                zonelink = () => {
                  hmApp.startApp({ url: "activityAppScreen", native: true });
                }
            };
            if (znum == 2) {
                calgr.setProperty(hmUI.prop.VISIBLE, false);
                readygr.setProperty(hmUI.prop.VISIBLE, false);
                oxygr.setProperty(hmUI.prop.VISIBLE, true);
                stressgr.setProperty(hmUI.prop.VISIBLE, false);
                zonelink = () => {
                  hmApp.startApp({ url: "spo_HomeScreen", native: true });
                }
            };
            if (znum == 3) {
                calgr.setProperty(hmUI.prop.VISIBLE, false);
                readygr.setProperty(hmUI.prop.VISIBLE, false);
                oxygr.setProperty(hmUI.prop.VISIBLE, false);
                stressgr.setProperty(hmUI.prop.VISIBLE, true);
                zonelink = () => {
                  hmApp.startApp({ url: "StressHomeScreen", native: true });
                }
            };
      }
// Основной модуль циферблата
      __$$module$$__.module = DeviceRuntimeCore.WatchFace({
// Функция создания интерфейса
          init_view() {
// фоновое изображение
              hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  w: 480,
                  h: 480,
                  src: 'nosecbg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
// Фон AOD
              hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: 'AOD.png',
                  show_level: hmUI.show_level.ONLY_AOD,
              });
// Иконка настроек
              hmUI.createWidget(hmUI.widget.IMG, {
                  x: 374,
                  y: 150,
                  src: 'settings.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Иконка idimas
              hmUI.createWidget(hmUI.widget.IMG, {
                  x: 367,
                  y: 333,
                  src: 'idimas.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Иконка тренировок
              hmUI.createWidget(hmUI.widget.IMG, {
                  x: 82,
                  y: 333,
                  src: 'run.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Иконка музыки
              hmUI.createWidget(hmUI.widget.IMG, {
                  x: 71,
                  y: 150,
                  src: 'musicRED.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Статус блокировки
              hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                  x: 306,
                  y: 56,
                  src: 'Lock ON.png',
                  type: hmUI.system_status.LOCK,
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Статус будильника
              hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                  x: 143,
                  y: 55,
                  src: 'Alarm ON.png',
                  type: hmUI.system_status.CLOCK,
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });                
// Время цифровое
      // Часы
              timeH = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 116,
                  y: 134,
                  w: 120,
                  h: 69,
                  char_space: -3,
                  font: proto,
                  color: '0x00FFFF',
                  text_size: 85,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
              });
      // Минуты
              timeMin = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                      x: 243,
                      y: 134,
                      w: 120,
                      h: 69,
                      char_space: -3,
                      font: proto,
                      color: '0x00FFFF',
                      text_size: 85,
                      text_style: hmUI.text_style.NONE,
                      align_h: hmUI.align.RIGHT,
                      align_v: hmUI.align.TOP,
                      type: hmUI.data_type.MINUTE,
                      padding: true,
      // Разделитель двоеточие
              });
              timeSep = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 220,
                  y: 130,
                  w: 40,
                  h: 69,
                  char_space: 0,
                  text: ":",
                  font: proto,
                  color: '0x00FFFF',
                  text_size: 78,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
              });
      // AM-PM
              ampmN = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 360,
                  y: 185,
                  w: 40,
                  h: 25,
                  text_size: 22,
                  char_space: 0,
                  line_space: 0,
                  font: proto,
                  color: 0x00FFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.NONE,
              });
              function updateTime() {
                  const hour = timeSens.hour;
                  const is24Hour = timeSens.is24Hour;
                  const format_hour = timeSens.format_hour;
                  let hourStr, ampmText

                  if (is24Hour) {
                      hourStr = format_hour.toString().padStart(2, '0');
                      ampmText = '';
                  } else {
                      hourStr = format_hour > 12 ? (format_hour - 12).toString().padStart(2, '0') : format_hour.toString().padStart(2, '0');
                      ampmText = (hour >= 0 && hour < 12) ? 'ДП' : 'ПП';
                  }
                  timeH.setProperty(hmUI.prop.TEXT, hourStr);
                  ampmN.setProperty(hmUI.prop.TEXT, ampmText);
              }
// Виджет заряда            
              batlevel = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 176,
                  y: 65,
                  w: 130,
                  h: 40,
                  char_space: -1,
                  text: 'Заряд',
                  font: proto,
                  color: '0xFF00FFFF',
                  text_size: 34,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
              });
              let battext = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 191,
                  y: 38,
                  w: 98,
                  h: 22,
                  char_space: -1,
                  font: proto,
                  color: '0xFF00FFFF',
                  text_size: 25,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.BOT,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              function updateBatery() {
                  const batcolor = getbatcolor(batsens.current);
                  batlevel.setProperty(hmUI.prop.MORE, { text: `${ String(batsens.current).padStart(3, '0') }%`,color: batcolor});
                  battext.setProperty(hmUI.prop.MORE, { text: `ЗАРЯД`,color: batcolor});
        }
// Виджет шагов
              step_n = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 118,
                  y: 321,
                  w: 250,
                  h: 80,
                  char_space: -2,
                  font: proto,
                  color: '0xFF00FFFF',
                  text_size: 70,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
              });
              let steptext = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 200,
                  y: 298,
                  w: 80,
                  h: 22,
                  char_space: -1,
                  font: proto,
                  color: '0xFF00FFFF',
                  text_size: 25,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              function updateSteps() {
                  const stepcolor = getstepcolor(stepSens.current);
                  step_n.setProperty(hmUI.prop.MORE, { text: `${ String(stepSens.current).padStart(5, '0') }`,color: stepcolor});
                  steptext.setProperty(hmUI.prop.MORE, { text: `ШАГИ`,color: stepcolor});
        }
// Виджет пульса
              hr_n = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 160,
                  y: 409,
                  w: 76,
                  h: 26,
                  text: 'HR',
                  font: proto,
                  color: '0xFF00FFFF',
                  text_size: 36,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              hr_text = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 164,
                  y: 378,
                  w: 76,
                  h: 24,
                  text: "ЧСС",
                  font: proto,
                  color: '0xFF0000',
                  text_size: 32,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              function updateHR() {
                  hr_n.setProperty(hmUI.prop.MORE, { text: `${ String(hrSens.last).padStart(3, '0') }`});
              }
// Виджет PAI
              pai_n = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 246,
                  y: 409,
                  w: 76,
                  h: 26,
                  text: 'PAI',
                  font: proto,
                  color: '0xFF00FFFF',
                  text_size: 36,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              paitext = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 243,
                  y: 378,
                  w: 76,
                  h: 24,
                  text: "PAI",
                  font: proto,
                  color: '0xA600FF',
                  text_size: 32,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              function updatePAI() {
                  const paicolor = getPAIcolor(paiSens.totalpai);
                  pai_n.setProperty(hmUI.prop.MORE, { text: `${ String(paiSens.totalpai).padStart(3, '0') }`,color: paicolor });
              }
// Виджет готовности
              readygr = hmUI.createWidget(hmUI.widget.GROUP);
              ready = readygr.createWidget(hmUI.widget.TEXT_FONT, {
                  x: 311,
                  y: 235,
                  w: 105,
                  h: 62,
                  font: proto,
                  color: 0x00FFFF,
                  text_size: 45,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.BOT,
                  type: hmUI.data_type.BIO_CHARGE,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              rtext = readygr.createWidget(hmUI.widget.TEXT, {
                  x: 260,
                  y: 276,
                  w: 175,
                  h: 25,
                  char_space: -2,
                  text: "БИОЗАРЯД",
                  font: proto,
                  color: 0x00FFFF,
                  text_size: 25,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
// Виджет калорий
              calgr = hmUI.createWidget(hmUI.widget.GROUP);
              calD = calgr.createWidget(hmUI.widget.TEXT_FONT, {
                  x: 311,
                  y: 240,
                  w: 105,
                  h: 62,
                  font: proto,
                  color: 0x00FFFF,
                  text_size: 40,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.BOT,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              calT = calgr.createWidget(hmUI.widget.TEXT, {
                  x: 253,
                  y: 276,
                  w: 170,
                  h: 25,
                  char_space: -2,
                  text: "КАЛОРИИ",
                  font: proto,
                  color: 0x00FFFF,
                  text_size: 25,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
// Виджет кислорода
              oxygr = hmUI.createWidget(hmUI.widget.GROUP);
              oxyD = oxygr.createWidget(hmUI.widget.TEXT_FONT, {
                  x: 265,
                  y: 240,
                  w: 105,
                  h: 62,
                  font: proto,
                  color: 0x00FFFF,
                  text_size: 40,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.BOT,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              oxyU = oxygr.createWidget(hmUI.widget.TEXT, {
                  x: 370,
                  y: 240,
                  w: 40,
                  h: 62,
                  text: "%",
                  font: proto,
                  color: 0x00FFFF,
                  text_size: 40,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.BOT,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              oxyT = oxygr.createWidget(hmUI.widget.TEXT, {
                  x: 263,
                  y: 276,
                  w: 170,
                  h: 25,
                  char_space: -2,
                  text: "КИСЛОРОД",
                  font: proto,
                  color: 0x00FFFF,
                  text_size: 25,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
// Виджет стресса
              stressgr = hmUI.createWidget(hmUI.widget.GROUP);
              strD = stressgr.createWidget(hmUI.widget.TEXT_FONT, {
                x: 311,
                y: 240,
                w: 105,
                h: 62,
                font: proto,
                color: 0x00FFFF,
                text_size: 40,
                text_style: hmUI.text_style.NONE,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.BOT,
                type: hmUI.data_type.STRESS,
                show_level: hmUI.show_level.ONLY_NORMAL
              });
              strT = stressgr.createWidget(hmUI.widget.TEXT, {
                x: 243,
                y: 276,
                w: 170,
                h: 25,
                char_space: -2,
                text: "СТРЕСС",
                font: proto,
                color: 0x00FFFF,
                text_size: 25,
                text_style: hmUI.text_style.NONE,
                align_h: hmUI.align.RIGHT,
                align_v: hmUI.align.TOP,
                show_level: hmUI.show_level.ONLY_NORMAL
              });
// Вмджет даты
              date_n = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 243,
                  y: 99,
                  w: 250,
                  h: 50,
                  char_space: -1,
                  font: proto,
                  color: '0xFF00FFFF',
                  text_size: 33,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
              });
              function updateDate() {
                  const daycolor = getDayColor(timeSens.week)
                  dateFormat = hmSetting.getDateFormat();
                  dateFormatMap = [
                      () => { // ГГГГ.ММ.ДД с нулями
                          date_n.setProperty(hmUI.prop.MORE, { text: `${ String(timeSens.month).padStart(2, '0') }.${ String(timeSens.day).padStart(2, '0') }`,color: daycolor});
                      },
                      () => { // ДД.ММ.ГГГГ с нулями
                          date_n.setProperty(hmUI.prop.MORE, { text: `${ String(timeSens.day).padStart(2, '0') }.${ String(timeSens.month).padStart(2, '0') }`,color: daycolor});
                      },
                      () => { // ММ.ДД.ГГГГ с нулями
                          date_n.setProperty(hmUI.prop.MORE, { text: `${ String(timeSens.month).padStart(2, '0') }.${ String(timeSens.day).padStart(2, '0') }`,color: daycolor});
                      }
                  ];
                  dateFormatMap[dateFormat]();
              }
// Виджет дня недели
              day_n = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 145,
                  y: 98,
                  w: 84,
                  h: 50,
                  text: 'day',
                  font: proto,
                  color: '0xFF00FFFF',
                  text_size: 32,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
              });
              function updateWday() {
                  const daycolor = getDayColor(timeSens.week)
                  const WEEK_DAY = function (val) {
                      const valueMap = {
                          '1': 'ПНД',
                          '2': 'ВТР',
                          '3': 'СРД',
                          '4': 'ЧТВ',
                          '5': 'ПТН',
                          '6': 'СБТ',
                          '7': 'ВСК'
                      };
                      return valueMap[val];
                  };
                  day_n.setProperty(hmUI.prop.MORE, { text: `${ WEEK_DAY(timeSens.week) }`,color: daycolor});
              }
// Погода и локация
              // Иконки погоды
              hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 101,
                  y: 204,
                  image_array: ["weather00.png","weather01.png","weather02.png","weather03.png","weather04.png","weather05.png","weather06.png","weather07.png","weather08.png","weather09.png","weather10.png","weather11.png","weather12.png","weather13.png","weather14.png","weather15.png","weather16.png","weather17.png","weather18.png","weather19.png","weather20.png","weather21.png","weather22.png","weather23.png","weather24.png","weather25.png","weather26.png","weather27.png","weather28.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
              // Температура
              temper_n = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 64,
                  y: 242,
                  w: 105,
                  h: 50,
                  text: 'Темп.',
        font: proto,
                  color: '0x00FFFF',
                  text_size: 35, 
        char_space: -1,
                  text_style: hmUI.text_style.NONE,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
      // Локация
              loc_n = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 64,
                  y: 276,
                  w: 315,
                  h: 50,
                  text: 'Загрузка...',
                  color: 0x00FFFF,
        font: proto,
                  text_size: 28,
        char_space: -1,
                  line_space: 0,
                  align_h: hmUI.align.LEFT,
        align_v: hmUI.align.TOP,
                  show_level: hmUI.show_level.ONLY_NORMAL
              });
              function updateWeather() {
                  const weatherData = wSens.getForecastWeather();
                  const city = weatherData.cityName || 'Не доступно';
                  loc_n.setProperty(hmUI.prop.TEXT, city);
                  Tunit = hmSetting.getTemperatureUnit() === 1 ? '°F' : '°C';   // Если 1 → Фаренгейты, иначе Цельсии
                  const temperature = wSens.current;
                  temper_n.setProperty(hmUI.prop.MORE, { text: `${temperature}${Tunit}` });
              }
// Время аналоговое
      // Часы
      hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                  hour_path: 'HOUR by rules.png',
                  hour_centerX: 240,
                  hour_centerY: 240,
                  hour_posX: 26,
                  hour_posY: 165,
                });
      // Минуты
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                  minute_path: 'Min new.png',
                  minute_centerX: 240,
                  minute_centerY: 240,
                  minute_posX: 30,
                  minute_posY: 204,
                });
      // // Секунды
              secondWidget = hmUI.createWidget(hmUI.widget.TEXT, {
                  w: 26,
                  h: 20,
                  text: "00",
                  color: 0xEB6100,
                  text_size: 18,
                  char_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  font: proto,
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
              updateSeconds();
              timer.createTimer(0, 1000, updateSeconds);

// 36912
              hmUI.createWidget(hmUI.widget.IMG, {
                  x: 0,
                  y: 0,
                  src: '36912.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка секундомер 
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 248,
                  y: 128,
                  w: 110,
                  h: 76,
                  press_src: '',
                  normal_src: '',
                  click_func: (button_widget) => {
                      hmApp.startApp({url: 'StopWatchScreen', native: true });
                      vibro()
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка таймер
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 122,
                  y: 128,
                  w: 110,
                  h: 76,
                  press_src: '',
                  normal_src: '',
                  click_func: (button_widget) => {
                      hmApp.startApp({url: 'CountdownAppScreen', native: true });
                      vibro()
                    },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка будильник
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 120,
                  y: 33,
                  w: 60,
                  h: 60,
                  press_src: '',
                  normal_src: '',
                  click_func: (button_widget) => {
                      hmApp.startApp({url: 'AlarmInfoScreen', native: true });
                      vibro()
                    },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка погода
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 60,
                  y: 208,
                  w: 116,
                  h: 90,
                  press_src: '',
                  normal_src: '',
                  click_func: (button_widget) => {
                      hmApp.startApp({url: 'WeatherScreen', native: true });
                      vibro()
                    },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка PAI
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 244,
                  y: 373,
                  w: 70,
                  h: 58,
                  press_src: '',
                  normal_src: '',
                  click_func: (button_widget) => {
                      hmApp.startApp({url: 'PAI_app_Screen', native: true });
                      vibro()
                    },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Переключаемая зона
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 310,
                  y: 210,
                  w: 120,
                  h: 120,
                  press_src: '',
                  normal_src: '',
                  click_func: (button_widget) => {
                      touchzone();
                      vibro();
                  },
                  longpress_func () {
                      zonelink ();
                      vibro ();
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка пульс
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 168,
                  y: 373,
                  w: 70,
                  h: 58,
                  press_src: '',
                  normal_src: '',
                  click_func: (button_widget) => {
                      hmApp.startApp({url: 'heart_app_Screen', native: true });
                      vibro()
                    },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка шаги
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 135,
                  y: 309,
                  w: 212,
                  h: 60,
                  press_src: '',
                  normal_src: '',
                  click_func: (button_widget) => {
                      hmApp.startApp({url: 'activityAppScreen', native: true });
                      vibro()
                    },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка музыка
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 40,
                  y: 124,
                  w: 80,
                  h: 80,
                  press_src: '',
                  normal_src: '',
                  click_func: (button_widget) => {
                  hmApp.startApp({url: 'MusicCommonScreen', native: true });
                  vibro();
                  },
                  longpress_func: (button_widget) => {
                  hmApp.startApp({url: 'LocalMusicScreen', native: true });
                  vibro();
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка заряд
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 190,
                  y: 36,
                  w: 100,
                  h: 90,
                  text: '',
                  color: 0xFFFF8C00,
                  text_size: 25,
                  press_src: 'Invisible.png',
                  normal_src: 'Invisible.png',
                  click_func: (button_widget) => {
                  hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
                  vibro();
                  },
                  longpress_func: (button_widget) => {
                  hmApp.startApp({url: 'LowBatteryScreen', native: true });
                  vibro();
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка карточки
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 348 ,
                  y: 320,
                  w: 80,
                  h: 80,
                  text: '',
                  press_src: 'Invisible.png',
                  normal_src: 'Invisible.png',
                  click_func: (button_widget) => {
                  hmApp.startApp({url: 'ClubCardsScreen', native: true });
                  vibro();
                  },
                  longpress_func () {
                      hmApp.startApp({ appid: 1003849, url: 'page/index' });
                      vibro ();
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка тренировки
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 54,
                  y: 320,
                  w: 80,
                  h: 80,
                  press_src: 'Invisible.png',
                  normal_src: 'Invisible.png',
                  click_func: (button_widget) => {
                  hmApp.startApp({url: 'SportListScreen', native: true });
                  vibro();
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// Кнопка настройки
              hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 360,
                  y: 124,
                  w: 80,
                  h: 80,
                  press_src: 'Invisible.png',
                  normal_src: 'Invisible.png',
                  click_func: (button_widget) => {
                  hmApp.startApp({url: 'Settings_homeScreen', native: true });
                  vibro();
                  },
                  longpress_func: (button_widget) => {
                  hmApp.startApp({url: 'HmReStartScreen', native: true });
                  vibro();
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });
// ОБНОВЛЕНИЕ ДАННЫХ
// Обновление времени
              timeSens.addEventListener(timeSens.event.MINUTEEND, function () {
                  updateTime();
                  updateSeconds();
              });
// Обновление батареи
              batsens.addEventListener(hmSensor.event.CHANGE, function () {
                  updateBatery()
              }),
// Обновление шагов               
              stepSens.addEventListener(hmSensor.event.CHANGE, function () {
                  updateSteps()
              }),
// Обновление пульса
              hrSens.addEventListener(hrSens.event.LAST, function () {
                  updateHR()
              }),
// Обновление PAI
              paiSens.addEventListener(hmSensor.event.CHANGE, function() {
                  updatePAI()
              }),
// Обновление даты и дня недели
              timeSens.addEventListener(timeSens.event.DAYCHANGE, function () {
                  updateDate();
                  updateWday();
              }),
// Обновление погоды и локации
              wSens.addEventListener(hmSensor.event.CHANGE, function() {
                  updateWeather()
              });
// Первичное состояние переключаемой зоны (скрыто всё, кроме готовности)
              let screenType = hmSetting.getScreenType();
              if (screenType != hmSetting.screen_type.AOD) {
                  calgr.setProperty(hmUI.prop.VISIBLE, false);
                  oxygr.setProperty(hmUI.prop.VISIBLE, false);
                  stressgr.setProperty(hmUI.prop.VISIBLE, false);
                  zonelink = () => {
                  hmApp.startApp({ url: 'readinessAppScreen', native: true });
                  }
              };
// Делегат возобновления работы
              hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                  resume_call: function () {
                      updateTime();
                      updateBatery();
                      updateSteps();
                      updateHR();
                      updatePAI();
                      updateDate();
                      updateWday();
                      updateWeather();
                      updateSeconds();
        }
              });
          },
// Жизненный цикл
          onInit() {
              logger.log('index page.js on init invoke');
          },
          build() {
              this.init_view();
              logger.log('index page.js on ready invoke');
          },
          onDestroy() {
              logger.log('index page.js on destroy invoke');
          }
      });
      ;
  })());
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
  ;
}